//
//  YagaSDK.h
//  YagaSDK
//
//  Created by oded regev on 21/05/2018.
//  Copyright © 2018 You Appi. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for YagaSDK.
FOUNDATION_EXPORT double YagaSDKVersionNumber;

//! Project version string for YagaSDK.
FOUNDATION_EXPORT const unsigned char YagaSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <YagaSDK/PublicHeader.h>

#import "YGManager.h"

